

let petSalon = {
    name:"the fashion pet",
    phone:"999-999-9999",
    address:{
        country:"US",
        city:"San Francisco",
        ZipCode:"12345",
    },
    pets:[
        {
            name:"Scooby",
            age:80,
            gender:"Male",
            Service:"Yes",
            Breed:"Great Dane",
        },
        {
            name:"Cujo",
            age:60,
            gender:"Male",
            Service:"No",
            Breed:"Pitbull",
        },
        {
            name:"Buddy",
            age:85,
            gender:"Male",
            Service:"Yes",
            Breed:"Golden Retriever",
        },
    ]
}
petSalonDatabase();